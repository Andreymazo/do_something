# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['do_something_project']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['do_something = do_something_project.welcome:main']}

setup_kwargs = {
    'name': 'do-something-project',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Andreymazo',
    'author_email': 'andreymazo@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
